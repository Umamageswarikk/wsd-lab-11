import React, { useState } from 'react';
import './App.css';
import { items } from './data';
import AddItem from './components/addItem';
import ItemList from './components/itemlist';
import EditItem from './components/Edititem';
import DeleteItem from './components/deleteItem';

function App() {
  const [itemList, setItemList] = useState(items);
  const [selectedItem, setSelectedItem] = useState(null);

  const handleAddItem = (newItem) => {
    setItemList([...itemList, { ...newItem, id: itemList.length + 1 }]);
  };

  const handleDeleteItem = (itemId) => {
    const updatedItems = itemList.filter((item) => item.id !== itemId);
    setItemList(updatedItems);
    setSelectedItem(null);
  };

  const handleUpdateItem = (itemId, updatedItem) => {
    const updatedItems = itemList.map((item) =>
      item.id === itemId ? { ...item, ...updatedItem } : item
    );
    setItemList(updatedItems);
    setSelectedItem(null);
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>CRUD App</h1>
      </header>
      <main>
        {selectedItem ? (
          <>
            <EditItem item={selectedItem} onUpdate={handleUpdateItem} />
            <DeleteItem item={selectedItem} onDelete={handleDeleteItem} />
          </>
        ) : (
          <>
            <AddItem onAdd={handleAddItem} />
            <ItemList
              items={itemList}
              onDelete={handleDeleteItem}
              onUpdate={setSelectedItem}
            />
          </>
        )}
      </main>
    </div>
  );
}

export default App;