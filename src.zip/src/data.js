export const items = [
    { id: 1, name: 'task-1', done: true },
    { id: 2, name: 'task-2', done: false },
    { id: 3, name: 'task-3', done: false },
    { id: 4, name: 'task-4', done: false },
    { id: 5, name: 'task-5', done: false },
  ];